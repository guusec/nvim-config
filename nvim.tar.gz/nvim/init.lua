require("core.plugins")
require("core.plugin_config")

vim.opt.mouse = ""
